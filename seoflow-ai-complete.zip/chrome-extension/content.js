document.body.style.outline="3px solid #6366f1";
