'use client';
import {useState} from 'react';

export default function Dashboard(){
const [text,setText]=useState("");
const [score,setScore]=useState(0);

const analyze=async()=>{
const res=await fetch("http://localhost:5000/api/analyze",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({content:text})
});
const data=await res.json();
setScore(data.score);
};

return (
<div style={{padding:40}}>
<textarea onChange={e=>setText(e.target.value)} style={{width:"100%",height:200}}/>
<button onClick={analyze}>Analyze</button>
<h2>Score: {score}</h2>
</div>
);
}
