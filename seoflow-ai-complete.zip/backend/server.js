require("dotenv").config();
const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

app.post("/api/analyze",(req,res)=>{
  const text=req.body.content||"";
  const words=text.split(" ");
  const score=Math.min(words.length/10,100);
  res.json({score,keywords:["seo","ai","content"]});
});

app.post("/api/rewrite",(req,res)=>{
  res.json({improved:"Improved: "+req.body.text});
});

app.listen(5000,()=>console.log("Backend running"));
